TB Simply download package
----------------------------------------------------------------------------------------
- Theme Version 1.0
- Packaged on: 2012-03-30
- Compatible with Drupal 7.x
- Copyright (C) 2011-2011 ThemeBrain.com. All Rights Reserved.
- @license - GNU/GPL, http://www.gnu.org/licenses/gpl.html
- Author: ThemeBrain
- Website: http://www.themebrain.com

Files Included
----------------------------------------------------------------------------------------
- README.txt
- tb_simply_with_demo_profile_v1.0.zip: demo profile for TB Simply
- nucleus_v1.0.zip: Nucleus base theme
- tb_simply_v1.0.zip: TB Simply theme

Installation
----------------------------------------------------------------------------------------
From Demo profile package:
This installation profile includes the same demo content of TB Simply at:
http://demo.themebrain.com/tb_simply/
Step 1: Extract demo profile package to your host.
Step 2: Navigate to the folder you have extracted the zip file and install themebrain profile.

Theme only installation:
Step 1: Extract included zip files Nucleus and TB Simply into sites/all/themes folder.
Step 2: Install Nucleus basetheme first. Go to theme settings under "Appearence" section and install this theme via upload.
Step 3: Install TB Simply theme. Go to theme settings under "Appearence" section and Install this theme via upload.
Step 4: Enable and set as default.

Documentation
----------------------------------------------------------------------------------------
Read the documentation of our themes at http://www.themebrain.com/guide
Drupal theming documentation in the Theme Guide: http://drupal.org/theme-guide
