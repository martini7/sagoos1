<?php

/**
 * @file
 * controls load theme.
 */

include_once drupal_get_path('theme', 'tb_events') . '/inc/theme_function_overrides.inc';
